// Part 3 - JS - st10534868
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('enquiryForm');
  if(form){
    form.addEventListener('submit', function(e){
      e.preventDefault();
      const name = document.getElementById('fullname').value.trim();
      const email = document.getElementById('email').value.trim();
      const msgEl = document.getElementById('formMessage');
      
      if(name.length < 3){ msgEl.textContent="Enter full name (min 3 chars)"; msgEl.style.color="red"; return;}
      if(!email.includes('@')){ msgEl.textContent="Enter valid email"; msgEl.style.color="red"; return;}
      
      msgEl.textContent = "Thank you " + name + "! Your volunteer/sponsor enquiry received.";
      msgEl.style.color="green";
      form.reset();
    });
  }
  // Animation
  document.querySelectorAll('h1').forEach(h=>{
    h.addEventListener('mouseover',()=>{h.style.transform="scale(1.03)"; h.style.transition="0.3s";});
    h.addEventListener('mouseout',()=>{h.style.transform="scale(1)";});
  });
});